def help():
    print('This is radari')